# Sedipack 

This is a simple package that is created to provide support to earth scientist and earth engineers (students in particuar).

This package seeks to help create an open-source solution to grain-size statistical analysis, and the production of grain plots.

Sedi pack is born out of the problems faced during the earlier days of the my final year thesis. 

The Problem I faced was: Software and Activation Keys which is or was expensive to get.

After Which I then thought to my self why was there no existing way to do it in python. Then I went to work.


## Available Functions.

The Package comprises of 4 Houses  of serveral functions.

1. *GrainPreprocess.*
2. *GrainViz.*
3. *GrainStasDes.*
4. *GrainDataTables.*



1. GrainPreprocess: has four calls that can be made. which are 
* MM_to_Phi()

*Bed_To_100()

*CummulateBed()

*Precentiles()

2.GrainViz: houses serveral calls which are

* DataFrame()

* DataFrame_PhiPercentiles()


* DataPlot()

3. GrainStatsDes: houses several calls which are 

* GraphicMean()

*GraphicStandard_Dev()

*GraphicSkewness()

*GraphicKurtosis()


4. GrainDataTables: houses several call which are 

* BedData()

* CompleteBeds()

* SaveBeds()



Which call contains a docstring which contains information on how to use it.


which of these functions can be import fromGrainPreprocess.


### Acknowledgements

I will like to also acknowledge the input of mentors and friends in this project.

1. Olawale Ibrahim (Machine Learning Engineer & The Author of Petroeval) & Emmanuel Jolaiya ( Machine Learning Engineer & The Author of rsgis and the Famous GISBOT on Twitter)

2. You  for using and reading this, Thank you.


Thank you all.
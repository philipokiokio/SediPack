Sedipack 

This is a simple package that is created to provide support to earth scientist and earth engineers (students in particuar).

This package seeks to help create an open-source solution to grain-size statistical analysis, and the production of grain plots.

Sedi pack is born out of the problems faced during the earlier days of the my final year thesis. 

The Problem I faced was: Software and Activation Keys which is or was expensive to get.

After Which I then thought to my self why was there no existing way to do it in python. Then I went to work.


The Package comprises of 4 Classes which houses serveral functions.

1. GrainPreprocess.
2. GrainViz.
3. GrainStasDes.
4. GrainDataTables.

This Classes class be called using a the (dot indication) `such as GrainPreprocess.BedTo100` and the likes or by expcitly stating the import.

[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
I will like to also acknowledge the input of mentors and friends in this project.

1. Olawale Ibrahim (Machine Learning Engineer & The Author of Petroeval) & Emmanuel Jolaiya ( Machine Learning Engineer &The Author of rsgis and the Famous GISBOT on Twitter)

2. Emeka Boris (A Machine Learning Engineer (NLP)and Co Author of Datassit) & Rising Odegua (A Machine Learning Engineer and the CO-Author of Datassit & Danfojs ).

3. You  for using and reading this, Thank you.


Thank you all.